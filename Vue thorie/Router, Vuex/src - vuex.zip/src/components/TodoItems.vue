<template>
  <div class="demo-alert-box">
    <strong>Error!</strong>
    <!-- <slot></slot> -->
  </div>
</template>
