<template>
  <div>
    <h2>YergeshKUAnyshbek</h2>
  </div>
</template>
